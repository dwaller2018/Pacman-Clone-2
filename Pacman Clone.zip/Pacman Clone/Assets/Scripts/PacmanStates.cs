﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PacmanStates : MonoBehaviour
{
    [SerializeField]
    private float invincibilityDurationSeconds;
    private IEnumerator coroutine;
    private bool invincible = false;

    // Start is called before the first frame update
    void Start()
    {
        coroutine = Invincible(invincibilityDurationSeconds);
        StartCoroutine(Invincible());
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Enemy")
        {
            if (!invincible)
            {
                Debug.Log("Triggered by Enemy");
                GameObject a = GameObject.Find("GameMaster");
                if (a)
                {
                    a.GetComponent<Health>().Damage();
                }
                else
                {
                    Debug.Log("ERROR: Cannot find GameMaster");
                }
            }

            else // If pacman is invincible, ignore collision
            {
                Physics.IgnoreCollision(GetComponent<Collider>(), GetComponent<Collider>());
            }

        }

    }

    private IEnumerator Invincible()
    {
        throw new NotImplementedException();
    }

    private IEnumerator Invincible(float time)
    {
        Debug.Log("Player turned invincible!");
        invincible = true;
        yield return new WaitForSeconds(time);
        invincible = false;
    }
}
