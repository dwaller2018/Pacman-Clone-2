﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    public int lives = 3;
    public GameObject PacmanLife;
    public GameObject Pacman;
    public float respawnDelay = 3;
    public float spawnX = 7;
    public float spawnY = 17;

    private int deleteLife;

    void Start()
    {
        for (int i = lives; i > 0; i--)
        {
            GameObject life = Instantiate(PacmanLife, new Vector2(-7, 29 - (lives * 2.0F) + (i * 2.0F)), Quaternion.identity);
            PacmanLife.name = "life" + i;
            Debug.Log(PacmanLife.name);
        }
    }

    //This is a debug section to test pacman getting damaged
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            Damage();
        }
    }

    public void Damage()
    {
        GameObject a = GameObject.Find("pacman");
        if (a)
        {
            Destroy(a);
            Debug.Log("Player was injured! " + lives + " lives left.");
        }
        else
        {
            Debug.Log("ERROR: Pacman not found.");
        }

        if (lives > 0)
        {
            lives--;
            StartCoroutine(respawn());
        }
        else
        {
            Debug.Log("GAME OVER");
        }

    }

    IEnumerator respawn()
    {
        Debug.Log("Respawning...");
        yield return new WaitForSeconds(respawnDelay);
        GameObject player = Instantiate(Pacman, new Vector2(spawnX, spawnY), Quaternion.identity);
        player.name = "pacman";
        deleteLife = lives + 1;
        GameObject b = GameObject.Find("life" + deleteLife + "(Clone)");
        if (b)
        {
            Destroy(b);
        }
    }
}
